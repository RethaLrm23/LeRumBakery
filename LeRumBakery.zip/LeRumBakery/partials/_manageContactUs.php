<?php
include '_dbconnect.php';
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['userId'];
    
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $orderId = mysqli_real_escape_string($conn, $_POST["orderId"]);
    $message = mysqli_real_escape_string($conn, $_POST["message"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);

    // Check user password is match or not
    $passSql = "SELECT * FROM users WHERE id='$userId'"; 
    $passResult = mysqli_query($conn, $passSql);
    $passRow=mysqli_fetch_assoc($passResult);
    
    if (password_verify($password, $passRow['password'])){
        $sql = "INSERT INTO `contact` (`userId`, `email`, `phoneNo`, `orderId`, `message`, `time`) VALUES ('$userId', '$email', '$phone', '$orderId', '$message', current_timestamp())";
        $result = mysqli_query($conn, $sql);
        $contactId = $conn->insert_id;
        echo '<script>alert("Thank You For Contacting Us! Your Contact ID: #' .$contactId. '. LeRum Bakery Will Contact You As Soon As Possible.");
                    window.location.href="http://localhost/LeRumBakery/index.php";  
                    </script>';
                    exit();
    }
    else{
        echo "<script>alert('Password Incorrect! Please Enter Correct Password For Your Account.');
                window.history.back(1);
                </script>";
    } 
}
?>
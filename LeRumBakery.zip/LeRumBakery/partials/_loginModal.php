<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    .login_form #username_error,
    .login_form #pass_error{
        margin-top: 5px;
        width: 300px;
        font-size: 18px;
        color: #C62828;
        background: rgba(255,0,0,0.1);
        text-align: center;
        padding: 5px 8px;
        border-radius: 3px;
        border: 1px solid #EF9A9A;
        display: none;
    }
  </style>
</head>
<body>
  <!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #a47c48;">
            <h5 class="modal-title" style="font-weight: bold; font-size: 30px; color:white;" id="loginModal">LeRum Bakery</h5>
            <button style="font-weight: bold; outline-style: none; color: #fff;" type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" style="Background: white; padding: 60px 100px;" >
            <form class="login_form" action="partials/_handleLogin.php" method="POST" name="form" onsubmit="return validated()">
              <div class="text-left my-2">
                  <b><label for="username">Username:</label></b>
                  <input class="form-control" id="loginusername" name="loginusername" placeholder="Enter Your Username" type="text">
                  <div id="username_error">Username Is Required</div>
                </div>
              <div class="text-left my-2" style="padding: 20px 0; ">
                  <b><label for="password">Password:</label></b>
                  <input class="form-control" id="loginpassword" name="loginpassword" placeholder="Enter Your Password" type="password">
                  <div id="pass_error">Password Is Required</div> 
                </div>
              <div style="padding-bottom: 10px">
                <button type="submit" class="btn" style="letter-spacing: 3px; background: #a47c48; color: white; font-weight: bold; width: 100%; outline-style: none;">LOGIN</button>
              </div>
            </form>
            <p class="mb-0 mt-1 text-center">Don't have an account? <a href="#" style="color: #a47c48; font-weight: 600;" data-dismiss="modal" data-toggle="modal" data-target="#signupModal">Register</a>.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script defer src="/LeRumBakery/assets/js/valid.js"></script>
</body>
</html>


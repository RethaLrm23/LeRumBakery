  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

  </head>
  <body>
     <!-- Sign up Modal -->
     <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModal" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #a47c48;">
            <h5 class="modal-title" style="font-weight: bold; font-size: 30px; color:white;" id="signupModal">LeRum Bakery</h5>
            <button style="font-weight: bold; outline-style: none; color: #fff;" type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" style="Background: white; padding: 30px 30px;">
            <form action="partials/_handleSignup.php" method="POST">
              <div class="form-group">
                  <b><label for="username">Username</label></b>
                  <input class="form-control" id="username" name="username" placeholder="Choose a unique Username" type="text" required minlength="3" maxlength="11">
                  <div class="error"></div>
              </div>
              <div class="form-row" style="padding-top: 10px;">
                <div class="form-group col-md-6">
                  <b><label for="firstName">First Name:</label></b>
                  <input type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required>
                  <div class="error"></div>
                </div>
                <div class="form-group col-md-6">
                  <b><label for="lastName">Last name:</label></b>
                  <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Last name" required>
                  <div class="error"></div>
                </div>
              </div>
              <div class="form-group" style="padding-top: 10px;">
                  <b><label for="email">Email:</label></b>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email" required>
                  <div class="error"></div>
              </div>
              <div class="form-group" style="padding-top: 10px;">
                <b><label for="phone">Phone:</label></b>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon">+27</span>
                  </div>
                  <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter Your Phone Number" required pattern="[0-9]{10}" maxlength="10">
                  <div class="error"></div>
                </div>
              </div>
              <div class="form-group text-left my-2" style="padding-top: 10px;">
                  <b><label for="password">Password:</label></b>
                  <input class="form-control" id="password" name="password" placeholder="Enter Password" type="password" required data-toggle="password" minlength="4" maxlength="21">
                  <div class="error"></div>
              </div>
              <div class="form-group text-left my-2" style="padding-top: 10px; padding-bottom: 10px;">
                  <b><label for="password1">Confirm Password:</label></b>
                  <input class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password" type="password" required data-toggle="password" minlength="4" maxlength="21">
                  <div class="error"></div>
              </div>
              <div style="padding-bottom: 10px">
                <button type="submit" class="btn" style="letter-spacing: 3px; background: #a47c48; color: white; font-weight: bold; width: 100%; outline-style: none;">REGISTER</button>
              </div>
            </form>
            <p class="mb-0 mt-1 text-center">Already have an account? <a href="#" style="color: #a47c48; font-weight: 600;" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">Login</a>.</p>
          </div>
        </div>
      </div>
    </div>

  </body>
  </html>
 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="footer container-fluid" style="background: #a47c48; color: white;">
        <p class="text-center py-2 mb-0">copyright &copy; 2023 LeRum Bakery. All rights reserved</p>
    </div> 

    <!-- Alertify.js JavaScript -->
    <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

    <script>

        <?php if(isset($_SESSION['message'])) { 
            ?>
            alertify.set('notifier','position', 'top-center');
            alertify.notify('<?= $_SESSION['message']; ?>'); 
            <?php
            unset($_SESSION['message']);
        }
        ?>
         
    </script>

</body>
</html>


<style>
    /* .modal-body {
        background-color: #eeeeee;
        font-family: 'Open Sans', serif
    } */

    .card {
        position: relative;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -ms-flex-direction: column;
        flex-direction: column;
        min-width: 0;
        word-wrap: break-word;
        background-color: #a47c48;
        background-clip: border-box;
    }

    .card-header:first-child {
        border-radius: calc(0.37rem - 1px) calc(0.37rem - 1px) 0 0
    }

    .card-header {
        padding: 0.75rem 1.25rem;
        margin-bottom: 0;
        background-color: #fff;
        border-bottom: 1px solid rgba(0, 0, 0, 0.1)
    }

    .track {
        position: relative;
        background-color: #fff;
        height: 7px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        margin-bottom: 60px;
        margin-top: 50px
    }

    .track .step {
        -webkit-box-flex: 1;
        -ms-flex-positive: 1;
        flex-grow: 1;
        width: 25%;
        margin-top: -18px;
        text-align: center;
        position: relative
    }

    .track .step.active:before {
        background: #a47c48;
    }

    .track .step::before {
        height: 7px;
        position: absolute;
        content: "";
        width: 100%;
        left: 0;
        top: 18px
    }

    .track .step.active .icon {
        background: #a47c48;
        color: #fff
    }

    .track .step.deactive:before {
        background: #a47c48;
    }

    .track .step.deactive .icon {
        background: #a47c48;
        color: #000;
    }

    .track .icon {
        display: inline-block;
        width: 40px;
        height: 40px;
        line-height: 40px;
        position: relative;
        border-radius: 100%;
        background: white
    }

    .track .step.active .text {
        font-weight: bold;
        color: #a47c48;
    }


    .track .text {
        display: block;
        margin-top: 7px
    }

    .btn-warning {
        color: #ffffff;
        background-color: #ee5435;
        border-color: #ee5435;
        border-radius: 1px
    }

    .btn-warning:hover {
        color: #ffffff;
        background-color: #ff2b00;
        border-color: #ff2b00;
        border-radius: 1px
    }

    p.one {
        word-spacing: 3px;
    }
    
</style>
<?php 
    $statusmodalsql = "SELECT * FROM `orders` WHERE `userId`= $userId";
    $statusmodalresult = mysqli_query($conn, $statusmodalsql);
    while($statusmodalrow = mysqli_fetch_assoc($statusmodalresult)){
        $orderid = $statusmodalrow['orderId'];
        $status = $statusmodalrow['orderStatus'];
        if ($status == 0) 
            $tstatus = "Order Placed";
        elseif ($status == 1) 
            $tstatus = "Order Received";
        elseif ($status == 2)
            $tstatus = "Preparing Your Order";
        elseif ($status == 3)
            $tstatus = "Out For Delivery";
        elseif ($status == 4) 
            $tstatus = "Order Delivered";
        elseif ($status == 5) 
            $tstatus = "Order Declined";
        else
            $tstatus = "Order Cancelled.";

        if($status >= 1 && $status <= 4) {
            
            $deliveryDetailSql = "SELECT * FROM deliverydetails WHERE orderId= $orderid";
            $deliveryDetailResult = mysqli_query($conn, $deliveryDetailSql);
            $deliveryDetailRow = mysqli_fetch_assoc($deliveryDetailResult);
            $trackId = $deliveryDetailRow['id']??null;
            $deliveryGuyName = $deliveryDetailRow['deliveryGuyName']??null;
            $deliveryGuyPhone = '0'.$deliveryDetailRow['deliveryGuyPhone']??null;
            $deliveryTime = $deliveryDetailRow['deliveryTime']??null;
            if($status == 4)
                $deliveryTime = 'xx';
            
        }   
        else {
            $trackId = 'xxxx';
            $deliveryGuyName = '';
            $deliveryGuyPhone = '';
            $deliveryTime = 'xx';
        }

?>
<!-- Modal -->
<div class="modal fade" id="orderStatus<?php echo $orderid; ?>" tabindex="-1" role="dialog" aria-labelledby="orderStatus<?php echo $orderid; ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content" style="background: #a47c48;">
            <div class="modal-header" style="color: #fff;">
                <h5 class="modal-title" id="orderStatus<?php echo $orderid; ?>">Status and Tracking</h5>
                <button style="background: #a47c48; color: #fff; outline-style: none;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="background: #000;" id="printThis">
                <div class="container" style="padding-right: 0px;padding-left: 0px;">
                    <article class="card" style="background: #000;" >
                        <div class="card-body">
                            <h6 style="color: white;"><strong>Order ID:</strong> <?php echo $orderid; ?></h6>
                            <article class="card">
                                <div class="card-body row">
                                    <div class="col"> <strong>Estimated Time:</strong><p style="color: white;"><i class="fa fa-clock"></i> <?php echo $deliveryTime; ?> minute</p></div>
                                    <div class="col"> <strong>Delivery Guy:</strong> <div style="color: white;"><i class="fa fa-truck"></i> <?php echo $deliveryGuyName; ?><p class="one"><i class="fa fa-phone"></i> <?php echo $deliveryGuyPhone; ?></div></div>
                                    <div class="col"> <strong>Status:</strong><p style="color: white;"><?php echo $tstatus; ?> </p></div>
                                    <div class="col"> <strong>Tracking Number:</strong><p style="color: white;"><?php echo $trackId; ?> </p></div>
                                </div>
                            </article>
                            <div class="track">
                            <?php
                                if($status == 0){
                                      echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text" style="color: white;">Order Received</span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text" style="color: white;"> Preparing Your Order</span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text" style="color: white;"> Out For Delivery </span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-map-marker"></i> </span> <span class="text" style="color: white;">Order Delivered</span> </div>';
                                }
                                elseif($status == 1){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Received</span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text" style="color: white;"> Preparing Your Order</span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text" style="color: white;"> Out For Delivery </span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-map-marker"></i> </span> <span class="text" style="color: white;">Order Delivered</span> </div>';
                                }
                                elseif($status == 2){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Received</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text"> Preparing Your Order</span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text"> style="color: white;" Out For Delivery </span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-map-marker"></i> </span> <span class="text" style="color: white;">Order Delivered</span> </div>';
                                }
                                elseif($status == 3){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Received</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text"> Preparing Your Order</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text"> Out For Delivery </span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-map-marker"></i> </span> <span class="text" style="color: white;">Order Delivered</span> </div>';
                                }
                                elseif($status == 4){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Received</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text"> Preparing Your Order</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text"> Out For Delivery </span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-map-marker"></i> </span> <span class="text">Order Delivered</span> </div>';
                                } 
                                elseif($status == 5){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step deactive"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text" style="color: red; font-weight: bold;">Order Declined.</span> </div>';
                                }
                                else {
                                    echo '<div class="step deactive"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text" style="color: red; font-weight: bold;">Order Cancelled.</span> </div>';
                                }
                            ?>
                            </div>
                            <div style="display: flex; justify-content: flex-end; margin-top: 100px;">
                               <a href="contact.php" class="btn " style="background:#fff; color: #000; font-weight: bold;" data-abc="true"><i class="fa fa-question-circle"></i> HELP DESK</a> 
                            </div>
                            
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }
?>


<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title id=title>Product</title>
    <link rel = "icon" href ="img/logo.png" type = "image/x-icon">
    <style>
        body{
            min-height: 100vh;
        }
        .footer{
            position: sticky;
            top: 100%;
        }
        #cont {
            min-height : 578px;
        }
        .row{
            background: #a47c48;
            color:white;
        }
        @media (max-width: 1366px) {
            .container {
                padding: 0 50px;
            }
        }

    </style>
</head>
<body>
    <?php include 'partials/_dbconnect.php';?>
    <?php require 'partials/_nav.php' ?>

    <div class="container my-4" style="padding-top: 50px;" id="cont">
        <div class="row jumbotron">
        <?php
            $productId = $_GET['productid'];
            $sql = "SELECT * FROM `product` WHERE productId = $productId";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
            $productName = $row['productName'];
            $productPrice = $row['productPrice'];
            $productDesc = $row['productDesc'];
            $productCategorieId = $row['productCategorieId'];
        ?>
        <script> document.getElementById("title").innerHTML = "<?php echo $productName; ?>"; </script> 
        <?php
        echo  '<div class="col-md-4">
                <img src="img/prod-'.$productId. '.jpg" width="249px" height="262px">
            </div>
            <div class="col-md-8 my-4">
                <h3>' . $productName . '</h3>
                <h5 style="color: #000; font-weight: bold; padding-bottom: 10px">R '.$productPrice. '.00</h5>
                <p class="mb-3">' .$productDesc .'</p>';

                if($loggedin){
                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE productId = '$productId' AND `userId`='$userId'";
                    $quaresult = mysqli_query($conn, $quaSql);
                    $quaExistRows = mysqli_num_rows($quaresult);
                    if($quaExistRows == 0) {
                        echo '<form action="partials/_manageCart.php" method="POST">
                              <input type="hidden" name="itemId" value="'.$productId. '">
                              <button type="submit" name="addToCart" class="btn my-3" style="background: #000; color: white;">Add to Cart</button>';
                    }else {
                        echo '<a href="viewCart.php"><button class="btn my-3" style="background: #000; color: white;">Go to Cart</button></a>';
                    }
                }
                else{
                    echo '<button class="btn my-3 " style="background: #000; color: white;" data-toggle="modal" data-target="#loginModal">Add to Cart</button>';
                }
                echo '</form>
                <div class="mx-0 py-3">
                    <a href="viewProductList.php?catid=' . $productCategorieId . '" class="active" style="color: #000">
                    <i class="fa fa-arrow-left"></i>
                        <span>Back</span>
                    </a>
                </div>
            </div>'
        ?>
        </div>
    </div>

    <div class="footer">
        <?php require 'partials/_footer.php' ?>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>
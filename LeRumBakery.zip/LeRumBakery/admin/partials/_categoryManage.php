<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['createCategory'])) {
        $name = mysqli_real_escape_string($conn, $_POST["name"]);
        $desc = mysqli_real_escape_string($conn, $_POST["desc"]);

        $sql = "INSERT INTO `categories` (`categorieName`, `categorieDesc`, `categorieCreateDate`) VALUES ('$name', '$desc', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
        $catId = $conn->insert_id;
        if($result) {
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check !== false) {
                
                $newfilename = "cate-".$catId.".jpg";

                $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/LeRumBakery/img/';
                $uploadfile = $uploaddir . $newfilename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
                    echo "<script>alert('Category Created Successfully');
                            window.location=document.referrer;
                        </script>";
                } else {
                    echo "<script>alert('Failed To Upload Image');
                            window.location=document.referrer;
                        </script>";
                }

            }
            else{
                echo '<script>alert("Select Image File To Upload.");
                    </script>';
            }
        }
    }
    if(isset($_POST['removeCategory'])) {
        $catId = mysqli_real_escape_string($conn, $_POST["catId"]);
        $filename = $_SERVER['DOCUMENT_ROOT']."/LeRumBakery/img/cate-".$catId.".jpg";
        $sql = "DELETE FROM `categories` WHERE `categorieId`='$catId'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            if (file_exists($filename)) {
                unlink($filename);
            }
            echo "<script>alert('Category Deleted Successfully');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Failed To Deleted Category');
                window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['updateCategory'])) {
        $catId = mysqli_real_escape_string($conn, $_POST["catId"]);
        $catName = mysqli_real_escape_string($conn, $_POST["name"]);
        $catDesc = mysqli_real_escape_string($conn, $_POST["desc"]);

        $sql = "UPDATE `categories` SET `categorieName`='$catName', `categorieDesc`='$catDesc' WHERE `categorieId`='$catId'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            echo "<script>alert('Category Updated Successfully');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Failed To Update Category');
                window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['updateCatPhoto'])) {
        $catId = mysqli_real_escape_string($conn, $_POST["catId"]);
        $check = getimagesize($_FILES["catimage"]["tmp_name"]);
        if($check !== false) {
            $newName = 'cate-'.$catId;
            $newfilename=$newName .".jpg";

            $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/LeRumBakery/img/';
            $uploadfile = $uploaddir . $newfilename;

            if (move_uploaded_file($_FILES['catimage']['tmp_name'], $uploadfile)) {
                echo "<script>alert('Category Picture Uploaded Successfully');
                        window.location=document.referrer;
                    </script>";
            } else {
                echo "<script>alert('Failed To Updated Category Picture');
                        window.location=document.referrer;
                    </script>";
            }
        }
        else{
            echo '<script>alert("Select Image File To Upload");
            window.location=document.referrer;
                </script>';
        }
    }
}
?>
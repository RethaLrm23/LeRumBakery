<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['updateDetail'])) {
        $name = mysqli_real_escape_string($conn, $_POST["name"]);
        $email = mysqli_real_escape_string($conn, $_POST["email"]);
        $contact1 = mysqli_real_escape_string($conn, $_POST["contact1"]);
        $contact2 = mysqli_real_escape_string($conn, $_POST["contact2"]);
        $addr = mysqli_real_escape_string($conn, $_POST["address"]);


        $sql = "UPDATE `sitedetail` SET systemName = '$name' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);
        $sql = "UPDATE `sitedetail` SET email = '$email' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);
        $sql = "UPDATE `sitedetail` SET contact1 = '$contact1' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);
        $sql = "UPDATE `sitedetail` SET contact2 = '$contact2' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);
        $sql = "UPDATE `sitedetail` SET `address` = '$addr' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);
        
        if($result){
            echo "<script>alert('Website Details Updated Successfully');
                window.location=document.referrer;
                </script>";
        }    
    }
    
}
?>
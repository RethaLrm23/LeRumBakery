<?php 
    $itemModalSql = "SELECT * FROM `orders`";
    $itemModalResult = mysqli_query($conn, $itemModalSql);
    while($itemModalRow = mysqli_fetch_assoc($itemModalResult)){
        $orderid = $itemModalRow['orderId'];
        $userid = $itemModalRow['userId'];
        $orderStatus = $itemModalRow['orderStatus'];
    
?>

<!-- Modal -->
<div class="modal fade" id="orderStatus<?php echo $orderid; ?>" tabindex="-1" role="dialog" aria-labelledby="orderStatus<?php echo $orderid; ?>" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #a47c48; color:#fff; font-weight: bold;">
        <h5 class="modal-title" id="orderStatus<?php echo $orderid; ?>">Order Status and Delivery Details</h5>
        <button style="color:#fff; outline-style: none;" type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background: #000; color: #fff;">
        <form action="partials/_orderManage.php" method="post" style="border-bottom: 2px solid #dee2e6; padding-bottom: 30px;">
            <div class="text-left my-2">    
                <b><label for="name">Order Status:</label></b>
                <div class="row mx-6 p-3 center">
                    <label for="" style="width: 300px; background: #a47c48; color: #fff; padding: 20px 20px; margin: 10px;">0=Order Placed<br> 1=Order Received<br> 2=Preparing Your Order<br> 3=Out For Delivery<br> 4=Order Delivered<br> 5=Order Declined<br> 6=Order Cancelled</label>
                    <input style="width: 300px; margin: 10px;" class="form-control col-md-3" id="status" name="status" value="<?php echo $orderStatus; ?>" type="number" min="0" max="6" required> 
                </div>
            </div>
            <input type="hidden" id="orderId" name="orderId" value="<?php echo $orderid; ?>">
            <button style="background:#a47c48; color: #fff; font-weight: bold; width: 100%;" type="submit" class="btn mb-2" name="updateStatus">UPDATE</button>
        </form>
        <?php   

            $deliveryDetailSql = "SELECT * FROM `deliverydetails` WHERE `orderId`= $orderid";
            $deliveryDetailResult = mysqli_query($conn, $deliveryDetailSql);
            $deliveryDetailRow = mysqli_fetch_assoc($deliveryDetailResult);                          
            $trackId = $deliveryDetailRow['id']??null;
            $deliveryGuyName = $deliveryDetailRow['deliveryGuyName']??null;
            $deliveryGuyPhone = $deliveryDetailRow['deliveryGuyPhone']??null;
            $deliveryTime = $deliveryDetailRow['deliveryTime']??null;           
            
            if($orderStatus>0 && $orderStatus<5) { 
        ?>
            <form action="partials/_orderManage.php" method="post" style=" padding-top: 10px;">
                <div class="text-left my-2">
                    <b><label for="name">Delivery Guy:</label></b>
                    <input class="form-control" id="name" name="name" value="<?php echo $deliveryGuyName; ?>" type="text" required>
                </div>
                <div class="text-left my-2 row" style=" padding: 10px 0;">
                    <div class="form-group col-md-6">
                        <b><label for="phone">Phone:</label></b>
                        <input class="form-control" id="phone" name="phone" value="0<?php echo $deliveryGuyPhone; ?>" type="tel" required pattern="[0-9]{10}">
                    </div>
                    <div class="form-group col-md-6">
                        <b><label for="catId">Estimated Time(minute):</label></b>
                        <input class="form-control" id="time" name="time" value="<?php echo $deliveryTime; ?>" type="number" min="1" max="120" required>
                    </div>
                </div>
                <input type="hidden" id="trackId" name="trackId" value="<?php echo $trackId; ?>">
                <input type="hidden" id="orderId" name="orderId" value="<?php echo $orderid; ?>">
                <button style="background:#a47c48; color: #fff; font-weight: bold; width: 100%;" type="submit" class="btn" name="updateDeliveryDetails">UPDATE</button>
            </form>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<?php
    }
?>

<style>
    .popover {
        top: -77px !important;
    }
</style>

<script>
    $(function () {
        $('[data-toggle="popover"]').popover();
    });
</script>
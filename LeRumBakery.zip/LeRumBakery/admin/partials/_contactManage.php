<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['contactReply'])) {
        $contactId = mysqli_real_escape_string($conn, $_POST['contactId']);
        $message = mysqli_real_escape_string($conn, $_POST['message']);
        $userId = mysqli_real_escape_string($conn, $_POST['userId']);
        
        $sql = "INSERT INTO `contactreply` (`contactId`, `userId`, `message`, `datetime`) VALUES ('$contactId', '$userId', '$message', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
        if($result) {
            echo "<script>alert('Message Was Sent Successfully');
                    window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Failed To Send Message');
                    window.location=document.referrer;
                </script>";
        }
    }
}
?>
<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['createItem'])) {
        $name = mysqli_real_escape_string($conn, $_POST["name"]);
        $description = mysqli_real_escape_string($conn, $_POST["description"]);
        $categoryId = mysqli_real_escape_string($conn, $_POST["categoryId"]);
        $price = mysqli_real_escape_string($conn, $_POST["price"]);

        $sql = "INSERT INTO `product` (`productName`, `productPrice`, `productDesc`, `productCategorieId`, `productPubDate`) VALUES ('$name', '$price', '$description', '$categoryId', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
        $productId = $conn->insert_id;
        if ($result){
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check !== false) {
                
                $newName = 'prod-'.$productId;
                $newfilename=$newName .".jpg";

                $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/LeRumBakery/img/';
                $uploadfile = $uploaddir . $newfilename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
                    echo "<script>alert('Product Create Successfully');
                            window.location=document.referrer;
                        </script>";
                } else {
                    echo "<script>alert('Failed To Create Product');
                            window.location=document.referrer;
                        </script>";
                }

            }
            else{
                echo '<script>alert("Select Image File To Upload.");
                        window.location=document.referrer;
                    </script>';
            }
        }
        else {
            echo "<script>alert('Failed To Create Product');
                    window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['removeItem'])) {
        $productId = mysqli_real_escape_string($conn, $_POST["productId"]);
        $sql = "DELETE FROM `product` WHERE `productId`='$productId'";   
        $result = mysqli_query($conn, $sql);
        $filename = $_SERVER['DOCUMENT_ROOT']."/LeRumBakery/img/prod-".$productId.".jpg";
        if ($result){
            if (file_exists($filename)) {
                unlink($filename);
            }
            echo "<script>alert('Product Deleted Successfully');
                window.location=document.referrer;
            </script>";
        }
        else {
            echo "<script>alert('Failed To Delete Product');
            window.location=document.referrer;
            </script>";
        }
    }
    if(isset($_POST['updateItem'])) {
        $productId = mysqli_real_escape_string($conn, $_POST["productId"]);
        $productName = mysqli_real_escape_string($conn, $_POST["name"]);
        $productDesc = mysqli_real_escape_string($conn, $_POST["desc"]);
        $productPrice = mysqli_real_escape_string($conn, $_POST["price"]);
        $productCategorieId = mysqli_real_escape_string($conn, $_POST["catId"]);

        $sql = "UPDATE `product` SET `productName`='$productName', `productPrice`='$productPrice', `productDesc`='$productDesc', `productCategorieId`='$productCategorieId' WHERE `productId`='$productId'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            echo "<script>alert('Product Updated Successfully');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Failed To Update Product');
                window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['updateItemPhoto'])) {
        $productId = mysqli_real_escape_string($conn, $_POST["productId"]);
        $check = getimagesize($_FILES["itemimage"]["tmp_name"]);
        if($check !== false) {
            $newName = 'prod-'.$productId;
            $newfilename=$newName .".jpg";

            $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/LeRumBakery/img/';
            $uploadfile = $uploaddir . $newfilename;

            if (move_uploaded_file($_FILES['itemimage']['tmp_name'], $uploadfile)) {
                echo "<script>alert('Product Picture Uploaded Successfully');
                        window.location=document.referrer;
                    </script>";
            } else {
                echo "<script>alert('Failed To Upload Product Picture');
                        window.location=document.referrer;
                    </script>";
            }
        }
        else{
            echo '<script>alert("Select Image File To Upload.");
            window.location=document.referrer;
                </script>';
        }
    }
}
?>
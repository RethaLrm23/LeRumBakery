<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .home{
            margin: auto;
            line-height: 200px;
            height: 850px;
            text-align: center;     
        }

        h1{
            margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        b{
            color: #a47c48;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="home">

        <h1>Welcome back <b><?php echo $_SESSION['adminusername']; ?></b></h1>
    
    </div>
</body>
</html>
	//Validtion Code For Inputs

    var username = document.forms['form']['loginusername'];
    var password = document.forms['form']['loginpassword'];
    
    var username_error = document.getElementById('username_error');
    var pass_error= document.getElementById('pass_error');
    
    username.addEventListener('textInput', username_Verify);
    password.addEventListener('textInput', pass_Verify);
    
    function validated(){
        if (username.value === "") {
            username.style.border = "1px solid red";
            username_error.style.display = "block";
            username.focus();
            return false;
        }

        if (password.value === "") {
            password.style.border = "1px solid red";
            pass_error.style.display = "block";
            password.focus();
            return false;
        }
    
    }
    function username_Verify(){
        if (username.value.length >= 3) {
            username.style.border = "1px solid silver";
            username_error.style.display = "none";
            return true;
        }
    }

    function pass_Verify(){
        if (password.value.length >= 4) {
            password.style.border = "1px solid silver";
            pass_error.style.display = "none";
            return true;
        }
    }